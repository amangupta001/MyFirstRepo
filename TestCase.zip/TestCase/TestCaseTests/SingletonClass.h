//
//  SingletonClass.h
//  
//
//  Created by Apple on 18/10/16.
//
//

#import <Foundation/Foundation.h>

@interface SingletonClass : NSObject

+ (instancetype)sharedInstance;
@end
