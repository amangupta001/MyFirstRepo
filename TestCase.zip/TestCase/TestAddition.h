//
//  TestAddition.h
//  
//
//  Created by Apple on 14/10/16.
//
//

#import <Foundation/Foundation.h>

@interface TestAddition : NSObject
-(NSInteger)addNumberOne:(NSInteger) firstNumber withNumberTwo:(NSInteger) secondNumber;

@end
