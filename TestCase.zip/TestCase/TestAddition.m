//
//  TestAddition.m
//  
//
//  Created by Apple on 14/10/16.
//
//

#import "TestAddition.h"

@implementation TestAddition
-(NSInteger)addNumberOne:(NSInteger) firstNumber withNumberTwo:(NSInteger) secondNumber {
    return firstNumber + secondNumber;
}

@end
